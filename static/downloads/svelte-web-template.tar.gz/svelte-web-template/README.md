Svelte Web Template
===================

<p>
    <img src="https://img.shields.io/badge/Svelte-3-ff3e00?style=for-the-badge&logo=svelte" alt="" />
</p>

For use with pnpm and Visual Studio Code.

Visual Studio Code Extensions
-----------------------------

  * Svelte for VS Code (`svelte.svelte-vscode`)
  * Axel’s Static Server (`axel669.static-serve`)

Building and Running Locally
----------------------------

```sh
curl -k https://kristorres.github.io/downloads/svelte-web-template.tar.gz | tar -xz
pnpm install
pnpm build/dev
```
